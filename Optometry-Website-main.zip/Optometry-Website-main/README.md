# Optometrist-Website
Responsive Website for Optometrist

### Introduction
#### Responsive website for optometrist office. Multiple breakpoints allow users to access on different types of devices with ease. 

### Technologies
#### This page uses the following:
- HTML
- CSS
- JavaScript
- JQuery

![optometrist](https://github.com/zaynahshabo/Optometry-Website/blob/main/Optometrist%20Website%20Design.gif)
![optometrist](https://github.com/zaynahshabo/Optometry-Website/blob/main/screenshot.png)
